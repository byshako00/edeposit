-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 28 Ağu 2017, 14:48:00
-- Sunucu sürümü: 5.6.37
-- PHP Sürümü: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `root`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `deposit`
--

CREATE TABLE `deposit` (
  `id` int(11) NOT NULL,
  `wallet` varchar(15) NOT NULL,
  `time` varchar(50) NOT NULL,
  `money` varchar(50) NOT NULL,
  `new_money` varchar(50) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `payment` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `options`
--

CREATE TABLE `options` (
  `id` int(11) NOT NULL,
  `site_name` text NOT NULL,
  `site_desc` text NOT NULL,
  `site_title` text NOT NULL,
  `admin_email` varchar(100) NOT NULL,
  `admin_password` varchar(100) NOT NULL,
  `mini_deposit` varchar(10) NOT NULL,
  `max_deposit` varchar(10) NOT NULL,
  `percent` varchar(5) NOT NULL,
  `percent_time` varchar(10) NOT NULL,
  `payeer_api_id` varchar(50) NOT NULL,
  `payeer_api_key` varchar(50) NOT NULL,
  `payeer_m_shop` varchar(50) NOT NULL,
  `payeer_m_key` varchar(50) NOT NULL,
  `payeer_m_comment` varchar(500) NOT NULL,
  `payeer_wallet` varchar(50) NOT NULL,
  `site_color` varchar(20) NOT NULL,
  `header_ad_1` text NOT NULL,
  `header_ad_2` text NOT NULL,
  `footer_ad_1` text NOT NULL,
  `footer_ad_2` text NOT NULL,
  `link_ad` text NOT NULL,
  `site_mode` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `options`
--

INSERT INTO `options` (`id`, `site_name`, `site_desc`, `site_title`, `admin_email`, `admin_password`, `mini_deposit`, `max_deposit`, `percent`, `percent_time`, `payeer_api_id`, `payeer_api_key`, `payeer_m_shop`, `payeer_m_key`, `payeer_m_comment`, `payeer_wallet`, `site_color`, `header_ad_1`, `header_ad_2`, `footer_ad_1`, `footer_ad_2`, `link_ad`, `site_mode`) VALUES
(1, 'RS1EZXBvc2l0', 'JiMxMDU0OyYjMTA4NTsmIzEwODM7JiMxMDcyOyYjMTA4MTsmIzEwODU7LSYjMTA4MDsmIzEwODU7JiMxMDc0OyYjMTA3NzsmIzEwODk7JiMxMDkwOyYjMTA4MDsmIzEwOTQ7JiMxMDgwOyYjMTA4MDsgJiMxMDgwOyAmIzEwNzk7JiMxMDcyOyYjMTA4ODsmIzEwNzI7JiMxMDczOyYjMTA3MjsmIzEwOTA7JiMxMDk5OyYjMTA3NDsmIzEwNzI7JiMxMDkwOyYjMTEwMDsgJiMxMDc2OyYjMTA3NzsmIzEwODU7JiMxMTAwOyYjMTA3NTsmIzEwODA7Lis1MCUgJiMxMDg3OyYjMTA4ODsmIzEwODA7JiMxMDczOyYjMTA5OTsmIzEwODM7JiMxMDgwOyAmIzEwNzk7JiMxMDcyOyA1MCAmIzEwODQ7JiMxMDgwOyYjMTA4NTsmIzEwOTE7JiMxMDkwOw==', 'RS1EZXBvc2l0IHwgJiMxMDU0OyYjMTA4NTsmIzEwODM7JiMxMDcyOyYjMTA4MTsmIzEwODU7LSYjMTA4MDsmIzEwODU7JiMxMDc0OyYjMTA3NzsmIzEwODk7JiMxMDkwOyYjMTA4MDsmIzEwOTQ7JiMxMDgwOyYjMTA4MDsgJiMxMDgwOyAmIzEwNzk7JiMxMDcyOyYjMTA4ODsmIzEwNzI7JiMxMDczOyYjMTA3MjsmIzEwOTA7JiMxMDk5OyYjMTA3NDsmIzEwNzI7JiMxMDkwOyYjMTEwMDsgJiMxMDc2OyYjMTA3NzsmIzEwODU7JiMxMTAwOyYjMTA3NTsmIzEwODA7', 'support@e-deposit.xyz', '1f68d06b65350fd01839daecb451e946', '1', '1000', '50', '50', '', '', '', '', '', '', '#413d8f', 'PGRpdiBpZD0ibGlua3Nsb3RfMTc5MTg1Ij48c2NyaXB0IHNyYz0iaHR0cHM6Ly9saW5rc2xvdC5ydS9iYW5jb2RlLnBocD9pZD0xNzkxODUiIGFzeW5jPjwvc2NyaXB0PjwvZGl2Pg==', 'PGRpdiBpZD0ibGlua3Nsb3RfMTc5MTg2Ij48c2NyaXB0IHNyYz0iaHR0cHM6Ly9saW5rc2xvdC5ydS9iYW5jb2RlLnBocD9pZD0xNzkxODYiIGFzeW5jPjwvc2NyaXB0PjwvZGl2Pg==', 'PGRpdiBpZD0ibGlua3Nsb3RfMTc5MTg3Ij48c2NyaXB0IHNyYz0iaHR0cHM6Ly9saW5rc2xvdC5ydS9iYW5jb2RlLnBocD9pZD0xNzkxODciIGFzeW5jPjwvc2NyaXB0PjwvZGl2Pg==', 'PGRpdiBpZD0ibGlua3Nsb3RfMTc5MTg4Ij48c2NyaXB0IHNyYz0iaHR0cHM6Ly9saW5rc2xvdC5ydS9iYW5jb2RlLnBocD9pZD0xNzkxODgiIGFzeW5jPjwvc2NyaXB0PjwvZGl2Pg==', 'PGNlbnRlcj48YSBocmVmPSJodHRwczovL2xpbmtzbG90LnJ1L2xpbmsucGhwP2lkPTE3OTE4NCIgdGFyZ2V0PSJfYmxhbmsiPiYjMTA1MDsmIzEwOTE7JiMxMDg3OyYjMTA4MDsmIzEwOTA7JiMxMTAwOyAmIzEwODk7JiMxMDg5OyYjMTA5OTsmIzEwODM7JiMxMDgyOyYjMTA5MTsgJiMxMDc5OyYjMTA3NjsmIzEwNzc7JiMxMDg5OyYjMTEwMDsgJiMxMDc5OyYjMTA3MjsgPHNwYW4gaWQ9ImxpbnByaWNlXzE3OTE4NCI+PC9zcGFuPiAmIzEwODg7JiMxMDkxOyYjMTA3MzsuPC9hPjxkaXYgaWQ9ImxpbmtzbG90XzE3OTE4NCIgc3R5bGU9Im1hcmdpbjogMTBweCAwOyI+PHNjcmlwdCBzcmM9Imh0dHBzOi8vbGlua3Nsb3QucnUvbGluY29kZS5waHA/aWQ9MTc5MTg0IiBhc3luYz48L3NjcmlwdD48L2Rpdj48YSBocmVmPSJodHRwczovL2xpbmtzbG90LnJ1Lz9yZWY9bXZtaXJyb3IiIHRhcmdldD0iX2JsYW5rIj4mIzEwNTU7JiMxMDg2OyYjMTA4OTsmIzEwOTA7JiMxMDcyOyYjMTA3NDsmIzEwODA7JiMxMDkwOyYjMTEwMDsgJiMxMDgyOyAmIzEwODk7JiMxMDc3OyYjMTA3MzsmIzEwNzc7ICYjMTA4NTsmIzEwNzI7ICYjMTA4OTsmIzEwNzI7JiMxMDgxOyYjMTA5MDs8L2E+PC9jZW50ZXI+', 'on');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `wallet` varchar(20) NOT NULL,
  `reg_ip` varchar(50) NOT NULL,
  `end_login_ip` varchar(50) NOT NULL,
  `date` varchar(15) NOT NULL,
  `blacklist` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `deposit`
--
ALTER TABLE `deposit`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `deposit`
--
ALTER TABLE `deposit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `options`
--
ALTER TABLE `options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
