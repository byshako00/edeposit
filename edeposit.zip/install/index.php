<?php error_reporting( 0 ); ?>
<center>
<h1>Installing Form</h1>
<form method="post" action="?action=check">
Site url: <input type="text" name="url" value="http://"><br>
Database host: <input type="text" name="host" value="localhost"><br>
Database user: <input type="text" name="user" placeholder="root"><br>
Database password: <input type="text" name="pass" placeholder=""><br>
Database name: <input type="text" name="name" placeholder="root"><br>
<input type="submit" value="Check Connection">
</form><br>
<?php
if (isset($_POST['host'])==TRUE and $_GET['action']=="check") {
	$url=$_POST['url'];
	$host=$_POST['host'];
	$user=$_POST['user'];
	$pass=$_POST['pass'];
	$name=$_POST['name'];
	if (empty($host)===TRUE||empty($user)===TRUE||empty($name)===TRUE||empty($url)===TRUE) {
		echo 'Please fill all fields';
	}else {
		
$conn = mysqli_connect($host, $user, $pass, $name);
if (!$conn) {
  echo 'Mysql connection error. <br/> Error reason: <b>' . mysqli_connect_error() . '</b>'; 
}elseif (filter_var($url, FILTER_VALIDATE_URL) === FALSE) {
    echo 'Website url not valid.';
}else {
	$fopen=fopen('../mysql_conf.dat', "w");
	fwrite($fopen, $url."\n".$host."\n".$user."\n".$pass."\n".$name);
	fclose($fopen);
	echo 'Connected Successfully<br><form method="post" action="?action=install">
<input type="submit" value="INSTALL">
</form>';
}
		
	}
}elseif ($_GET['action']=="install") {
	
	if (file_exists('../mysql_conf.dat')===FALSE) {
		echo "<br> Please connect mysql";
	}else {
		//mysql install php start
		
$file=file('../mysql_conf.dat');
	
$host = trim($file[1]);
$uname = trim($file[2]);
$pass = trim($file[3]);
$database = trim($file[4]);
$filename = 'import.sql'; 

$conn = new mysqli($host, $uname, $pass, $database);
$op_data = '';
$lines = file($filename);
foreach ($lines as $line)
{
    if (substr($line, 0, 2) == '--' || $line == '')//This IF Remove Comment Inside SQL FILE
    {
        continue;
    }
    $op_data .= $line;
    if (substr(trim($line), -1, 1) == ';')//Breack Line Upto ';' NEW QUERY
    {
        $conn->query($op_data);
        $op_data = '';
    }
}
		echo 'Installing successfull.  go to<br/> Home page: <a href="'.trim($file[0]).'">'.trim($file[0]).'</a><br/>Admin Panel: <a href="'.trim($file[0]).'/adminpanel.php">'.trim($file[0]).'/adminpanel.php</a>';
		//mysql install php end
	}
	
}

?>