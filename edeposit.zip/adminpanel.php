<?php
session_start();

include('config.php');

if (isset($_SESSION['attempts'])==FALSE) {
	$_SESSION['attempts']="3";
}
if ($_SESSION['code']!==$admin_code && $_SESSION['attempts'] > 1) {
	
		if (isset($_POST['code'])==TRUE) {
		if (md5($_POST['code'])!==$admin_code) {
			$_SESSION['attempts']=$_SESSION['attempts']-1;
		}else {
			$_SESSION['code']=md5($_POST['code']);
			echo '<a href="?">Please click to reload page</a>';
		}
	}
	
	echo '<form method="post"><input type="password" placeholder="Password" name="code"><input type="submit" value="login"></form><br>Number of password attempts: ' . $_SESSION['attempts'];
	

	
}else {
?>
	<style type="text/css">
		#tables{background-color:#F5F5F5;}
		 
		#tables td{border:red 1px solid;}
		
		#s{ background-color:<?=$site_color?>; padding:2px; border-radius:5px; padding-left:7px; padding-right:7px; font-weight:bold; color:#FFFFFF; }
		#s:hover{ background-color:#FFFFFF; color:<?=$site_color?>; }
#s2{ display:block; color:#FFFFFF;}
#s2:hover{ color:<?=$site_color?>;}
        body{ 
        margin:0; 
        font:0.82em/1.4 Verdana,sans-serif; 
        min-width:780px; 
        }
		p{
			margin:1em 0
		 }
		table{
			margin:0 auto;
			font:1.01em/1.4 Arial,sans-serif;
			background: #f4f4f4;
			color:#000
			}
		a{text-decoration:none;}
		.htt:hover {background-color:#ccffcc;}
		
		input:focus{
background-image:none;}
		input{ border-radius:8px;}
		</style>
		
		
		<?php
$withdrawed_orginal=mysqli_query($conn, 'select money from deposit where payment="success"')->num_rows;	
$canceled_orginal=mysqli_query($conn, 'select money from deposit where payment="fail"')->num_rows;	
$users_orginal=mysqli_query($conn, 'select wallet from users')->num_rows;
$deposit_orginal = mysqli_query($conn, 'select money from deposit where payment="waiting"')->num_rows;
$pending_deposit_orginal = mysqli_query($conn, 'select money from deposit where payment="pending"')->num_rows;

if ($_GET['page']=="wdcd") {
	$colorwd="orange";
}elseif ($_GET['page']=="pg") {
	$colorpg="orange";
}elseif ($_GET['page']=="us") {
	$colorus="orange";
}elseif ($_GET['page']=="os") {
	$coloros="orange";
}else {
	$colordo="orange";
}
		?>
		
		<table width="930px" border="0" bgcolor="D4D0C8">
	<tbody><tr align="center">
	 
		<td width="460" id="s"><a id="s2" href="?" style="text-decoration: none;"><font color="<?=$colordo?>" size=" ">Opened deposit (<?=$deposit_orginal?>)</font></a></td>
		
		<td width="460" id="s"><a id="s2" href="?page=wdcd" style="text-decoration: none;  "><font color="<?=$colorwd?>" size=" ">Withdrawed(<?=$withdrawed_orginal?>)/Canceled(<?=$canceled_orginal?>) </font></a></td>
		
		<td width="460" id="s"><a id="s2" href="?page=pg" style="text-decoration: none;  "><font color="<?=$colorpg?>" size=" ">Pending (<?=$pending_deposit_orginal?>)</font></a></td>
		
		<td width="460" id="s"><a id="s2" href="?page=us" style="text-decoration: none;  "><font color="<?=$colorus?>" size=" ">Users (<?=$users_orginal?>)</font></a></td>
		
		<td width="460" id="s"><a id="s2" href="?page=os" style="text-decoration: none;  "><font color="<?=$coloros?>" size=" ">Options</font></a></td>
				
		<td width="460" id="s"><a id="s2" href="?page=et" style="text-decoration: none;  "><font color="" size=" ">Exit</font></a></td>
		 	
	</tr>

</tbody></table>

<?php
$page=$_GET['page'];
////// "exit" started
if ($page=="et") {
	session_destroy();
	echo '<a href="'.$siteurl.'">Please click to go site</a>';
//// "exit" end
/// "Withdrawed/Canceled" starded
}else if ($page=="wdcd") {
    	echo '<center>';
   if ($_GET['action']=="addbot" and isset($_POST['num'])==TRUE) {
       if (empty($_POST['num'])==FALSE and is_numeric($_POST['num'])==TRUE){
           
           for ($x = 1; $x <= $_POST['num']; $x++) {
               
     $wallet="P".rand('1000000','9999999')."B";
           $time=time()-2150;
           $money=rand('1','15').'.00';
           $new_money=($money*$percent/100)+$money;
$insert="INSERT INTO `deposit` (`id`, `wallet`,`time`, `money`, `new_money`, `ip`, `payment`) VALUES (NULL, '".$wallet."', '".$time."', '".$money."', '".$new_money."', '0.0.0.0', 'success')";
if (mysqli_query($conn, $insert)) {} else {}
if ($_POST['num']==$x) {
    echo 'Adding bot success';
}
} 
       }else {
           echo 'Error adding bot';
       }
       echo '<br>';
   }
	?>
	<form method="post" action="?page=wdcd&action=addbot">Add withdrawed bot: <input type="number" placeholder="How many" name="num"><input type="submit" value="add"></form></center>
	<hr>
	<table width="930" border="0" cellpadding="0" cellspacing="0" id="tables">
<tbody>
    <tr bgcolor="blue" style="color:#FFFFFF;">
	<td align="center" width="100px"><b>Wallet</b></td>
	<td align="center" width="100px"><b>Money</b></td>
	<td align="center" width="100px"><b>Withdrawed/Canceled</b></td>
  </tr>  
    <?php
  $query = "SELECT * FROM deposit where payment='fail' or payment='success'";

if ($result = mysqli_query($conn, $query)) {

    /* fetch associative array */
    while ($row = mysqli_fetch_assoc($result)) {
        
	if ($row['ip']!=="0.0.0.0") {	
		
       echo '<tr class="htt">
	<td align="center"><img border="0" align="center" src="pay.png"> '.$row['wallet'].'</td>
	<td align="center"><img border="0" align="center" src="money.png"> '.$row['new_money'].' rub </td>
		<td align="center">'.$row['payment'].'</td></td>
  	</tr>';
	}
    }
    

    /* free result set */
    mysqli_free_result($result);
}

?>

  </tbody>
 </table>
	<?php
	/// "Withdrawed/Canceled" ended
	/// pending started
}elseif ($page=="pg") {
	echo '<center><b>';

	
	if ($_GET['action']=="cancel") {
		$insert="UPDATE deposit SET payment='fail' WHERE id='".$_GET['id']."'";
			if (mysqli_query($conn, $insert)) {echo $_GET['wallet'].' money cancelled.';} else {echo $_GET['wallet'].' money cancelled error.';}
	}elseif ($_GET['action']=="pay") {
		//////////////////////////////////////////
		
		require_once('cpayeer.php');
		$payeer = new CPayeer($accountNumber, $apiId, $apiKey);
		
		
		if ($payeer->isAuth()){
			
		$arTransfer = $payeer->transfer(array(
		'curIn' => 'RUB',
		'sum' => ''.$_GET['money'].'',
		'curOut' => 'RUB',
		//'sumOut' => 1,
		'to' => ''.$_GET['wallet'].'',
		//'to' => 'client@mail.com',
		'comment' => $m_comment,
		//'anonim' => 'Y',
		//'protect' => 'Y',
		//'protectPeriod' => '3',
		//'protectCode' => '12345',
	));
	if (empty($arTransfer['errors']))
	{
	
	$insert="UPDATE deposit SET payment='success' WHERE id='".$_GET['id']."'";
			if (mysqli_query($conn, $insert)) {echo $_GET['wallet'].' money withdrawed.';} else {echo $_GET['wallet'].' money withdrawed error.';}
		
	}
	else
	{
		echo 'Error money withdraw.';
	}


		
}
else
{
	echo 'Error.. Payeer not authorized';
}
		
		//////////////////////////////////////////
	}
	
	echo '</b></center>';
	
	?><center>
	<a href="?page=pg&action=show_bots">Show Bots</a>
	<table width="930" border="0" cellpadding="0" cellspacing="0" id="tables">
<tbody>
    <tr bgcolor="blue" style="color:#FFFFFF;">
	<td align="center" width="100px"><b>Wallet</b></td>
	<td align="center" width="100px"><b>Money</b></td>
		<td align="center" width="100px"><b>Ip</b></td>
	<td align="center" width="100px"><b>Withdraw/Cancel</b></td>
  </tr>  
    <?php
  $query = "SELECT * FROM deposit where payment='pending'";

if ($result = mysqli_query($conn, $query)) {

    /* fetch associative array */
    while ($row = mysqli_fetch_assoc($result)) {
		
		if ($row['ip']!=="0.0.0.0") {
       echo '<tr class="htt">
	<td align="center"><img border="0" align="center" src="pay.png"> '.$row['wallet'].'</td>
	<td align="center"><img border="0" align="center" src="money.png"> '.$row['new_money'].' rub </td>
	<td align="center">'.$row['ip'].' </td>
		<td align="center"><a href="?page=pg&action=pay&wallet='.$row['wallet'].'&money='.$row['new_money'].'&id='.$row['id'].'">Pay</a> / <a href="?page=pg&action=cancel&id='.$row['id'].'">Cancel</a></td></td>
  	</tr>';
		}elseif ($row['ip']=="0.0.0.0" and $_GET['action']=="show_bots") {
		   echo '<tr class="htt">
	<td align="center"><img border="0" align="center" src="pay.png"> '.$row['wallet'].'</td>
	<td align="center"><img border="0" align="center" src="money.png"> '.$row['new_money'].' rub </td>
	<td align="center">'.$row['ip'].' </td>
		<td align="center"><a href="?page=pg&action=pay&wallet='.$row['wallet'].'&money='.$row['new_money'].'&id='.$row['id'].'">Pay</a> / <a href="?page=pg&action=cancel&id='.$row['id'].'">Cancel</a></td></td>
  	</tr>'; 
		}
    }

    /* free result set */
    mysqli_free_result($result);
}

?>

  </tbody>
 </table>
	<?php
/// pending ended
/// "users" started
}elseif ($page=="us") {
    echo '<center>';
   if ($_GET['action']=="addbot" and isset($_POST['num'])==TRUE) {
       if (empty($_POST['num'])==FALSE and is_numeric($_POST['num'])==TRUE){
           
           for ($x = 1; $x <= $_POST['num']; $x++) {
               
$wallet="P".rand('1000000','9999999')."B";
$date=date("d/m/Y");
$insert="INSERT INTO `users` (`id`, `wallet`, `reg_ip`, `end_login_ip`, `date`, `blacklist`) VALUES (NULL, '$wallet', '0.0.0.0', '0.0.0.0', '$date', '0')";
if (mysqli_query($conn, $insert)) {} else {}
if ($_POST['num']==$x) {
    echo 'Adding bot success';
}
} 
       }else {
           echo 'Error adding bot';
       }
       echo '<br>';
   }
    
    
	?>
	<form method="post" action="?page=us&action=addbot">Add user bot: <input type="number" placeholder="How many" name="num"><input type="submit" value="add"></form>
		<a href="?page=us&action=show_bots">Show Bots</a>
	</center>
	<hr>
	
	
	<table width="930" border="0" cellpadding="0" cellspacing="0" id="tables">
<tbody>
    <tr bgcolor="blue" style="color:#FFFFFF;">
	<td align="center" width="100px"><b>Wallet</b></td>
	<td align="center" width="100px"><b>Ip</b></td>
	<td align="center" width="100px"><b>Last login ip</b></td>
	<td align="center" width="100px"><b>(Un)Block / Delete</b></td>
  </tr>  
    <?php
	if (isset($_GET['wallet'])==TRUE) {
	echo '<center><b>';
	if ($_GET['action']=="unblock"){
		$insert="UPDATE users SET blacklist='0' WHERE wallet='".$_GET['wallet']."'";
			if (mysqli_query($conn, $insert)) {echo $_GET['wallet'].' unblock successfully.';} else {echo $_GET['wallet'].' unblock error.';}
	}elseif ($_GET['action']=="block") {
	$insert="UPDATE users SET blacklist='1' WHERE wallet='".$_GET['wallet']."'";
			if (mysqli_query($conn, $insert)) {echo $_GET['wallet'].' block successfully.';} else {echo $_GET['wallet'].' block error.';}
	}elseif ($_GET['action']=="delete") {
		$insert="DELETE FROM users WHERE wallet='".$_GET['wallet']."'";
			if (mysqli_query($conn, $insert)) {echo $_GET['wallet'].' delete user successfully.';} else {echo $_GET['wallet'].' delete user error.';}
			$insert="DELETE FROM deposit WHERE wallet='".$_GET['wallet']."'";
			if (mysqli_query($conn, $insert)) {echo 'delete user data successfully.';} else {echo 'delete user data error.';}
	}
	echo '</b></center>';
	}
	
	
  $query = "SELECT * FROM users";

if ($result = mysqli_query($conn, $query)) {

    /* fetch associative array */
    while ($row = mysqli_fetch_assoc($result)) {
		$wallet=$row['wallet'];
		
		if ($row['blacklist']==1) {
			$blockunblock='<a href="?wallet='.$wallet.'&action=unblock&page=us">Unblock</a>';
		}else {
			$blockunblock='<a href="?wallet='.$wallet.'&action=block&page=us">Block</a>';
		}
			if ($row['reg_ip']!=="0.0.0.0" or $row['end_login_ip']!=="0.0.0.0") {
       echo '<tr class="htt">
	<td align="center"><img border="0" align="center" src="pay.png"> '.$wallet.'</td>
	<td align="center"> '.$row['reg_ip'].' </td>
	<td align="center"> '.$row['end_login_ip'].' </td>
	<td align="center"> '.$blockunblock.' / <a href="?wallet='.$wallet.'&action=delete&page=us">Delete</a></td>
	
  	</tr>';
			}elseif ($row['reg_ip']=="0.0.0.0" and $_GET['action']=="show_bots") {
			    echo '<tr class="htt">
	<td align="center"><img border="0" align="center" src="pay.png"> '.$wallet.'</td>
	<td align="center"> '.$row['reg_ip'].' </td>
	<td align="center"> '.$row['end_login_ip'].' </td>
	<td align="center"> '.$blockunblock.' / <a href="?wallet='.$wallet.'&action=delete&page=us">Delete</a></td>
	
  	</tr>';  
			}
    }

    /* free result set */
    mysqli_free_result($result);
}

?>

  </tbody>
 </table>
	<?php
/// "users" end
/// "options" started
}elseif ($page=="os") {


	if ($option['site_mode']=="off") {
		$maintace="checked='checked'";
	}else {
		$maintace="";
	}
	
	echo '<center>';
	// save
	if ($_POST) {
		$site_name=base64_encode($_POST['site_name']);
		$site_title=base64_encode($_POST['site_title']);
		$site_desc=base64_encode($_POST['site_desc']);
		$site_color=$_POST['site_color'];
		if ($_POST['site_mode']=="on") {
		$site_mode="off";
		}else {
		$site_mode="on";  
		}
		$mini_deposit=$_POST['mini_deposit'];
		$max_deposit=$_POST['max_deposit'];
		$percent=$_POST['percent'];
		$percent_time=$_POST['percent_time'];
		$admin_email=$_POST['admin_email'];
		$admin_password=md5($_POST['admin_password']);
		$payeer_wallet=$_POST['payeer_wallet'];
		$payeer_api_id=$_POST['payeer_api_id'];
		$payeer_api_key=$_POST['payeer_api_key'];
		$payeer_m_shop=$_POST['payeer_m_shop'];
		$payeer_m_key=$_POST['payeer_m_key'];
		$payeer_m_comment=$_POST['payeer_m_comment'];
		$header_ad_1=base64_encode($_POST['header_ad_1']);
		$header_ad_2=base64_encode($_POST['header_ad_2']);
		$footer_ad_1=base64_encode($_POST['footer_ad_1']);
		$footer_ad_2=base64_encode($_POST['footer_ad_2']);
		$link_ad=base64_encode($_POST['link_ad']);
		
		
		
		if (empty($_POST['admin_password'])==FALSE) {
			$_SESSION['code']=$admin_password;
			$admin_password=md5($_POST['admin_password']);
		}else {
			$admin_password=$option['admin_password'];
		}
		
		
		
	$query=mysqli_query($conn, "UPDATE options SET site_name='{$site_name}',site_desc='{$site_desc}',site_color='{$site_color}',site_mode='{$site_mode}',payeer_m_shop='{$payeer_m_shop}',payeer_m_shop='{$payeer_m_shop}',payeer_m_key='{$payeer_m_key}',payeer_m_comment='{$payeer_m_comment}',header_ad_1='{$header_ad_1}',header_ad_2='{$header_ad_2}',footer_ad_1='{$footer_ad_1}',footer_ad_2='{$footer_ad_2}',link_ad='{$link_ad}',payeer_wallet='{$payeer_wallet}',payeer_api_id='{$payeer_api_id}',payeer_api_key='{$payeer_api_key}',site_title='{$site_title}',admin_email='{$admin_email}',admin_password='{$admin_password}',mini_deposit='{$mini_deposit}',max_deposit='{$max_deposit}',percent='{$percent}',percent_time='{$percent_time}' WHERE id=1");
		
		if ($query) {
			echo 'Save completed';
			echo '<br><a href="?page=os">Please click me to reload</a>';
		}else {
			echo 'Save not completed';
			echo '<br><a href="?page=os">Please click me to reload and change again</a>';
		}
		
	}
	
	echo '</center>';
	?>
	
	<table width="930" border="0" cellpadding="0" cellspacing="0" id="tables">
<tbody>
    <tr bgcolor="blue" style="color:#FFFFFF;">
	<td align="center" width="100px"><b>Text</b></td>
	<td align="center" width="100px"><b>Values</b></td>
  </tr>  
  <form method="post" action="?page=os">
  <tr class="htt"><td align="center">Site name: </td><td align="center"><input value="<?=base64_decode($option['site_name'])?>" type="text" name="site_name" /></td></tr>
  <tr class="htt"><td align="center">Site title: </td><td align="center"><input value="<?=base64_decode($option['site_title'])?>" type="text" name="site_title" /></td></tr>
  <tr class="htt"><td align="center">Site description: </td><td align="center"><textarea name="site_desc"><?=base64_decode($option['site_desc'])?></textarea></td></tr>
  <tr class="htt"><td align="center">Site color (Click to select color): </td><td align="center"><input value="<?=$option['site_color']?>" type="color" name="site_color" /></td></tr>
  <tr class="htt"><td align="center">Site maintace (checked=closed): </td><td align="center"><input <?=$maintace?> type="checkbox" name="site_mode"></td></tr>
  <tr class="htt"><td align="center">Minimum deposit: </td><td align="center"><input value="<?=$option['mini_deposit']?>" type="text" name="mini_deposit" /></td></tr>
  <tr class="htt"><td align="center">Maximum deposit: </td><td align="center"><input value="<?=$option['max_deposit']?>" type="text" name="max_deposit" /></td></tr>
  <tr class="htt"><td align="center">Percent: </td><td align="center"><input value="<?=$option['percent']?>" type="text" name="percent" /></td></tr>
  <tr class="htt"><td align="center">Percent time: </td><td align="center"><input value="<?=$option['percent_time']?>" type="text" name="percent_time" /></td></tr>
  <tr class="htt"><td align="center">Admin email: </td><td align="center"><input value="<?=$option['admin_email']?>" type="text" name="admin_email" /></td></tr>
  <tr class="htt"><td align="center">Admin password: </td><td align="center"><input value="" type="text" name="admin_password" /></td></tr>
  <tr class="htt"><td align="center">Your payeer wallet: </td><td align="center"><input value="<?=$option['payeer_wallet']?>" type="text" name="payeer_wallet" /></td></tr>
  <tr class="htt"><td align="center">Payeer api id: </td><td align="center"><input value="<?=$option['payeer_api_id']?>" type="text" name="payeer_api_id" /></td></tr>
  <tr class="htt"><td align="center">Payeer api key: </td><td align="center"><input value="<?=$option['payeer_api_key']?>" type="text" name="payeer_api_key" /></td></tr>
  <tr class="htt"><td align="center">Payeer merchant id: </td><td align="center"><input value="<?=$option['payeer_m_shop']?>" type="text" name="payeer_m_shop" /></td></tr>
  <tr class="htt"><td align="center">Payeer merchant secret key: </td><td align="center"><input value="<?=$option['payeer_m_key']?>" type="text" name="payeer_m_key" /></td></tr>
  <tr class="htt"><td align="center">Payeer comment(send and receive money comment): </td><td align="center"><input value="<?=$option['payeer_m_comment']?>" type="text" name="payeer_m_comment" /></td></tr>
  <tr class="htt"><td align="center">Header ad (1): </td><td align="center"><textarea name="header_ad_1"><?=base64_decode($option['header_ad_1'])?></textarea></td></tr>
  <tr class="htt"><td align="center">Header ad (2): </td><td align="center"><textarea name="header_ad_2"><?=base64_decode($option['header_ad_2'])?></textarea></td></tr>
  <tr class="htt"><td align="center">Footer ad (1): </td><td align="center"><textarea name="footer_ad_1"><?=base64_decode($option['footer_ad_1'])?></textarea></td></tr>
  <tr class="htt"><td align="center">Footer ad (2): </td><td align="center"><textarea name="footer_ad_2"><?=base64_decode($option['footer_ad_2'])?></textarea></td></tr>
  <tr class="htt"><td align="center">Link ad: </td><td align="center"><textarea name="link_ad"><?=base64_decode($option['link_ad'])?></textarea></td></tr>

    <tr class="htt"><td align="center">Save: </td><td align="center"><input type="submit" value="Save"/></textarea></td></tr>
  
 </form>
   
   
  </tbody>
 </table>
  
	<?php
}
/// "options" ended
/// "default-od" started
else {
echo '<center><b>';
	
	if ($_GET['action']=="addbot" and isset($_POST['num'])==TRUE) {
       if (empty($_POST['num'])==FALSE and is_numeric($_POST['num'])==TRUE){
           
           for ($x = 1; $x <= $_POST['num']; $x++) {
               
     $wallet="P".rand('1000000','9999999')."B";
     $percent_time=$percent_time;
           $time=time()+((60)*$percent_time)-$x-1;
           $money=rand('1','15').'.00';
           $new_money=($money*$percent/100)+$money;
$insert="INSERT INTO `deposit` (`id`, `wallet`,`time`, `money`, `new_money`, `ip`, `payment`) VALUES (NULL, '".$wallet."', '".$time."', '".$money."', '".$new_money."', '0.0.0.0', 'waiting')";
if (mysqli_query($conn, $insert)) {} else {}
if ($_POST['num']==$x) {
    echo 'Adding bot success';
}
} 
       }else {
           echo 'Error adding bot';
       }
       echo '<br>';
   }
	
	if ($_GET['action']=="delete") {
		if (empty($_GET['id'])==FALSE) {
		$insert="DELETE FROM deposit WHERE id='".$_GET['id']."'";
		if (mysqli_query($conn, $insert)) {echo 'delete deposit successfully.';} else {echo 'delete deposit error.';}
		}else {
			echo 'Deposit id not found';
		}
	}elseif ($_GET['action']=="deleterefun") {
		
		if (empty($_GET['id'])==FALSE or empty($_GET['wallet'])==FALSE) {
			
		
		require_once('cpayeer.php');
		$payeer = new CPayeer($accountNumber, $apiId, $apiKey);
		
		
		if ($payeer->isAuth()){
			
		$arTransfer = $payeer->transfer(array(
		'curIn' => 'RUB',
		'sum' => ''.$_GET['money'].'',
		'curOut' => 'RUB',
		//'sumOut' => 1,
		'to' => ''.$_GET['wallet'].'',
		//'to' => 'client@mail.com',
		'comment' => $m_comment,
		//'anonim' => 'Y',
		//'protect' => 'Y',
		//'protectPeriod' => '3',
		//'protectCode' => '12345',
	));
	if (empty($arTransfer['errors']))
	{
	
	$insert="UPDATE deposit SET payment='refund' WHERE id='".$_GET['id']."'";
			if (mysqli_query($conn, $insert)) {echo $_GET['wallet'].' money refunded.';} else {echo $_GET['wallet'].' money refunded error.';}
		
	}
	else
	{
		echo 'Error money refund.';
	}


		
}
else
{
	echo 'Error.. Payeer not authorized';
}
		
		
		
		}else {
			echo 'Deposit id not found';
		}
	}
	
	
	echo '</b></center>';
	echo '<center>';
	?>
		<form method="post" action="?action=addbot">Add deposit bot: <input type="number" placeholder="How many" name="num"><input type="submit" value="add"></form>
			<a href="?action=show_bots">Show Bots</a>
		</center>

	<hr>
	
	<table width="930" border="0" cellpadding="0" cellspacing="0" id="tables">
<tbody>
    <tr bgcolor="blue" style="color:#FFFFFF;">
	<td align="center" width="100px"><b>id</b></td>
	<td align="center" width="100px"><b>Wallet</b></td>
	<td align="center" width="100px"><b>Money</b></td>
	<td align="center" width="100px"><b>Time</b></td>
	<td align="center" width="100px"><b>Withdraw</b></td>
	<td align="center" width="60px"><b>Delete / Delete&Refund / Delete user</b></td>
  </tr>  
  
  
  
  
   
    <?php
  $query = "SELECT * FROM deposit where payment='waiting' ORDER BY time DESC";

if ($result = mysqli_query($conn, $query)) {

    /* fetch associative array */
    while ($row = mysqli_fetch_assoc($result)) {
		$wallet=$row['wallet'];
		
		$time1=$row['time']-time();
		if ($time1 < 1) {
			$time="00:00";
		}else {
			$time=gmdate("i:s", $time1);
		}
		
		if ($row['ip']!=='0.0.0.0') {
		
       echo '<tr class="htt">
	   <td align="center">'.$row['id'].'</td>
	<td align="center"><img border="0" align="center" src="pay.png"> '.$wallet.'</td>
    <td align="center"><img border="0" align="center" src="money.png"> '.$row['money'].' rub</td>
	<td align="center"><div class="countdown">'.$time.' </td></td>
	<td align="center"><img border="0" align="center" src="money.png"> '.$row['new_money'].' rub </td>
	<td align="center"> <a href="?action=delete&id='.$row['id'].'">Delete</a> / <a href="?action=deleterefun&id='.$row['id'].'&wallet='.$row['wallet'].'&money='.$row['money'].'">Delete&Refund</a> / <a href="?wallet='.$row['wallet'].'&action=delete&page=us">Delete user</a></td>
  	</tr>';
    }elseif ($row['ip']=='0.0.0.0' and $_GET['action']=="show_bots"){
      echo '<tr class="htt">
	   <td align="center">'.$row['id'].'</td>
	<td align="center"><img border="0" align="center" src="pay.png"> '.$wallet.'</td>
    <td align="center"><img border="0" align="center" src="money.png"> '.$row['money'].' rub</td>
	<td align="center"><div class="countdown">'.$time.' </td></td>
	<td align="center"><img border="0" align="center" src="money.png"> '.$row['new_money'].' rub </td>
	<td align="center"> <a href="?action=delete&id='.$row['id'].'">Delete</a> / <a href="?action=deleterefun&id='.$row['id'].'&wallet='.$row['wallet'].'&money='.$row['money'].'">Delete&Refund</a> / <a href="?wallet='.$row['wallet'].'&action=delete&page=us">Delete user</a></td>
  	</tr>';  
    }
    
    
    }

    /* free result set */
    mysqli_free_result($result);
}

?>

  </tbody>
 </table>
 <?
}}?>