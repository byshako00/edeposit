<?php
error_reporting( 0 ); 
if (file_exists('mysql_conf.dat')===FALSE) {
		echo '<br> Please install script. Go to: <a href="install/index.php">Installer</a> ';
		exit();
	}
	

$file=file('mysql_conf.dat');
	
$siteurl=trim($file[0]);
$host = trim($file[1]);
$user = trim($file[2]);
$pass = trim($file[3]);
$db=trim($file[4]);



/////////////////////


$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$result_option = mysqli_query($conn, "SELECT * FROM options ORDER by ID LIMIT 1");
$option = mysqli_fetch_array($result_option, MYSQLI_BOTH);

$title=base64_decode($option['site_title']);
$site_desc=base64_decode($option['site_desc']);
$site_name=base64_decode($option['site_name']);
$site_color=$option['site_color'];

$mini_deposit=$option['mini_deposit'];
$max_deposit=$option['max_deposit'];
$percent=$option['percent'];
$percent_time=$option['percent_time'];

$admin_code=$option['admin_password'];

$email=$option['admin_email'];

$m_shop = $option['payeer_m_shop'];
$m_key = $option['payeer_m_key'];
$m_comment=$option['payeer_m_comment'];
$accountNumber = $option['payeer_wallet'];
$apiId = $option['payeer_api_id'];
$apiKey = $option['payeer_api_key'];


?>

