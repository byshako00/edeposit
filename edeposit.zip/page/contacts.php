<?php
if (basename($_SERVER["SCRIPT_FILENAME"], '.php')=="contacts") {
exit('<meta http-equiv="refresh" content="0; url=/" />');
}
?>

<br><style type="text/css">
<!--
.style1 {
	font-size: 14px;
	font-weight: bold;
}
-->
</style><hr>
<p style=" background-color:#F4F4F4; height:100px; padding-top:50px; text-align:center;"><br>Перед обращением укажите в письме свой логин (payeer кошелек) <br><strong><span class="style1"><?=$option['admin_email']?> (это наш модератор проекта)</b></span></strong><br>



<hr>