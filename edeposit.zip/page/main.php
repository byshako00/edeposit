<?php
if (basename($_SERVER["SCRIPT_FILENAME"], '.php')=="main") {
exit('<meta http-equiv="refresh" content="0; url=/" />');
}
?>
<center>
<div class="banner">
<div>

			
			<?php


			if (empty($_POST['wallet'])===FALSE) {
				$wallet=$_POST['wallet'];
				$strops = strpos($wallet, "P");
				if ($strops===FALSE) {
					$respcolor="red";
					$response="Создать свой номер кошелька правильно. Пример: P8146317";
				}else {
					$users=mysqli_query($conn, "select wallet from users where wallet='$wallet'");
					$countusers=$users->num_rows;
					if ($countusers==0) {
						
$ip=$_SERVER['REMOTE_ADDR'];
$date=date("d/m/Y");
$insert="INSERT INTO `users` (`id`, `wallet`, `reg_ip`, `end_login_ip`, `date`, `blacklist`) VALUES (NULL, '$wallet', '$ip', '$ip', '$date', '0')";
if (mysqli_query($conn, $insert)) {
} else {
  //  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	exit('Error please contact admin: '.$email.'');
}
						$respcolor="green";
						$response='Пожалуйста, подождите';
						echo '<script>document.location.href = "'.$siteurl.'?page=my";</script>';
						$_SESSION['wallet']=$wallet;
					}else {
						$ip=$_SERVER['REMOTE_ADDR'];
						$insert="UPDATE users SET end_login_ip='".$ip."' WHERE wallet='".$wallet."'";
			if (mysqli_query($conn, $insert)) {} else {}
						$respcolor="green";
						$response= 'Пожалуйста, подождите';
						echo '<script>document.location.href = "'.$siteurl.'?page=my";</script>';
						$_SESSION['wallet']=$wallet;
						
					}
				}
			}
			
			?>
		
<?php
if (isset($_SESSION['wallet'])==FALSE) {
?>
		<form action="?" method="post">		
			<table bgcolor="F5F5F5" width="930" height="21px" border="0" cellpadding="0" cellspacing="0">
			<tbody><tr>
				<td align="center">
				
				
								<b>Ваш кошелек Payeer:</b> <br> <input placeholder="PXXXXXXX" value="<?=$_SESSION['wallet']?>" name="wallet" type="text" size="23" maxlength="35"></td>
			</tr>
			<tr>
				<td align="center"><input type="submit" name="submit" id="form" value="Вход | Регистрация"></td>
			</tr>
		  </tbody></table><br>
		  <font color="<?=$respcolor?>"><?=$response?></font>
		</form>
	<?php	
}else {
	echo '<h4><a href="'.$siteurl.'?page=my">Возврат к учетной записи</a> или <a href="'.$siteurl.'?page=exit">выход из системы</a></h4>';
}
		?>
				
	</div></div>
</center>

<?php
if (empty($option['link_ad'])==FALSE) {
echo '<center><hr> реклама <br>'.base64_decode($option['link_ad']).'<hr></center>';
}
?>

<br><style type="text/css">
.style1 {
	font-size: 14px;
	font-weight: bold;
}
</style>
 <div align="center"><span class="style1">+<?=$percent?>% прибыли за <?=$percent_time?> минут</span>
 </div>
 <? 
 if ($_GET['payments']=="on") {
$_GET['action']="payments";
 }else {
$_GET['action']="main";
 }
 include_once('pay_list.php') ?>