<?php

if (basename($_SERVER["SCRIPT_FILENAME"], '.php')=="my") {
exit('<meta http-equiv="refresh" content="0; url=/" />');
}


if (!isset($_SESSION['wallet'])) {
	exit('<meta http-equiv="refresh" content="0; url=?page=main" />');
}


if (empty($_POST['amount'])==FALSE) {
	$amount=$_POST['amount'];
	if (is_numeric($amount)==TRUE){
if ($amount >= $mini_deposit){
if ($amount <= $max_deposit){
	
$m_orderid = $_SESSION['wallet'];
$m_amount = number_format($amount, 2, '.', '');
$m_curr = 'RUB';
$m_desc = base64_encode($m_comment);


$arHash = array(
	$m_shop,
	$m_orderid,
	$m_amount,
	$m_curr,
	$m_desc
);

$arHash[] = $m_key;

$sign = strtoupper(hash('sha256', implode(':', $arHash)));

$paying='<form method="post" action="https://payeer.com/merchant/">
<input type="hidden" name="m_shop" value="'.$m_shop.'">
<input type="hidden" name="m_orderid" value="'.$m_orderid.'">
<input type="hidden" name="m_amount" value="'.$m_amount.'">
<input type="hidden" name="m_curr" value="'.$m_curr.'">
<input type="hidden" name="m_desc" value="'.$m_desc.'">
<input type="hidden" name="m_sign" value="'.$sign.'">

<input type="submit" hidden id="m_process_submit_js" name="m_process" value="депозит" />
</form>
<script>document.getElementById("m_process_submit_js").click();</script>';

	}else {
		$pay_message='Самая большая денежная стоимость: '.$max_deposit;	;
	}		
	}else {
		$pay_message='Наименьшая денежная стоимость: '.$mini_deposit;
	}
	}else {
		$pay_message='Деньги еще не были введены правильно';		
	}

}

?>



<table width="930px" border="0" bgcolor="#F5F5F5">
	<tbody><tr>  
		 
		
		<?//<td width="169"><a id="s" href="/?page=referals" style="text-decoration: none"><font color="" size=" ">Рефералы</font></a></td>?>
		<td width="251" style="background-color:red; padding:2px; border-radius:5px; padding-left:7px; padding-right:7px; font-weight:bold; color:#FFFFFF;"><font color="" size=" ">привет <?=$_SESSION['wallet']?> </font></a></td>
		<td width="751"><a id="s" href="/?page=my" style="text-decoration: none"><font color="" size=" ">Мои депозиты</font></a></td>
		
		<td width="751"> </td>
		<td width="180"><a id="s" href="/?page=exit" style="text-decoration: none"><font color="white" size="3">Выход</font></a></td>		
	 
	</tr>
</tbody></table>
<?php

$blockrow = "SELECT * FROM users where wallet='".$_SESSION['wallet']."'";
$blockrow = mysqli_query($conn, $blockrow);
$blockrow = mysqli_fetch_assoc($blockrow);

if ($blockrow['blacklist']==0) {
?>


<form action="" method="post">	

<table bgcolor="F5F5F5" width="930" height="21px" border="0" cellpadding="0" cellspacing="0" background="">

		
			<tbody><tr>
				<td align="center">
				<?php
				if ($_GET['payeer']=="fail") {
				echo '<font color="red"><b>Ошибка при внесении</b></font><Br>';
				}
				?>
								<b>Введите сумму вклада (от <?=$mini_deposit?> до <?=$max_deposit?> рублей) </b> <br><br>
<b><div id="result"></div></b>
								<br><input onkeyup="updateText(this.value);" style="text-align:center;" name="amount" type="text" value="<?php echo empty($amount) ? "100":$amount; ?>" size="5" maxlength="10">
								<br>
								<?php
						echo '<font color="red">'.$pay_message.'</font>';
								?>
								</td>
							
								</form>
								<?php
								echo $paying;
								?>
			</tr>
			<tr>
				<td align="center">
				<br>
				<input type="submit" value="Сделать вклад"><br><br></td>
			</tr>
		  </tbody></table>
		  
		  <?
}else {
?>
 <br><br>
<table bgcolor="F5F5F5" width="930" height="21px" border="0" cellpadding="0" cellspacing="0" background="">
			<tbody><tr>
				<td align="center">
								<h4><b>Ваша учетная запись была заблокирована. Как связаться с администратором</b> </h4>
			</tr>
		  </tbody></table>
		  <br><br>


<?php
}
		  ?>
				
		
		
		
		<center><?php
if (empty($option['link_ad'])==FALSE) {
echo '<center><hr> реклама <br>'.base64_decode($option['link_ad']).'<hr></center>';
}
?></center>
 


<br><style type="text/css">
.style1 {
	font-size: 14px;
	font-weight: bold;
}
</style>
 <div align="center"><span class="style1">+<?=$percent?>% прибыли за <?=$percent_time?> минут</span>
 </div>
 
 <? 
 if ($_GET['payments']=="on") {
$_GET['action']="payments";
 }else {
$_GET['action']="my";
 }
 include_once('pay_list.php') ?>