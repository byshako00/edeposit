<?php
session_start();
unset($_SESSION['wallet']);
exit('<meta http-equiv="refresh" content="0; url=?page=main" />');
?>