<?php
if ($_GET['action']=="main") {
?>
<br>
	<div align="center"><span class="style1">Последние 10 депозит</span>
 </div>
<table width="930" border="0" cellpadding="0" cellspacing="0" id="tables">
<tbody>
    <tr bgcolor="<?=$site_color?>" style="color:#FFFFFF;">
	<td align="center" width="100px"><b>Кошелек</b></td>
	<td align="center" width="100px"><b>Депозит</b></td>
	<td align="center" width="100px"><b>Осталось</b></td>
	<td align="center" width="100px"><b>На вывод</b></td>
  </tr>  
    <?php
  $query = "SELECT * FROM deposit where payment='waiting' ORDER BY time DESC LIMIT 10";

if ($result = mysqli_query($conn, $query)) {

    /* fetch associative array */
    while ($row = mysqli_fetch_assoc($result)) {
		$wallet=substr($row['wallet'], 0, 4);
		
		$time1=$row['time']-time();
		if ($time1 < 1) {
			$time="00:00";
		}else {
			$time=gmdate("i:s", $time1);
		}
	
       echo '<tr class="htt">
	<td align="center"><img border="0" align="center" src="pay.png"> '.$wallet.'<font color="navy">XXXX</font></td>
    <td align="center"><img border="0" align="center" src="money.png"> '.$row['money'].' руб.</td>
	<td align="center"><div class="countdown">'.$time.' </td></td>
	<td align="center"><img border="0" align="center" src="money.png"> '.$row['new_money'].' руб. </td>
  	</tr>';
    }

    /* free result set */
    mysqli_free_result($result);
}

?>

  </tbody>
 </table>
 
 <?php
}elseif ($_GET['action']=="payments") {
	?>
	<br>
	<div align="center"><span class="style1">Последние 10 заплатили деньги</span>
 </div>
<table width="930" border="0" cellpadding="0" cellspacing="0" id="tables">
<tbody>
    <tr bgcolor="blue" style="color:#FFFFFF;">
	<td align="center" width="100px"><b>Wallet</b></td>
	<td align="center" width="100px"><b>Old money</b></td>
	<td align="center" width="100px"><b>New money</b></td>
		<td align="center" width="100px"><b>Payment</b></td>
  </tr>  
    <?php
  $query = "SELECT * FROM deposit where payment='success' ORDER BY id DESC LIMIT 10";

if ($result = mysqli_query($conn, $query)) {

    /* fetch associative array */
    while ($row = mysqli_fetch_assoc($result)) {
		$wallet=substr($row['wallet'], 0, 4);
		
       echo '<tr class="htt">
	<td align="center"><img border="0" align="center" src="pay.png"> '.$wallet.'XXXX</td>
	<td align="center"><img border="0" align="center" src="money.png"> '.$row['money'].' rub </td>
	<td align="center"><img border="0" align="center" src="money.png"> '.$row['new_money'].' rub </td>
		<td align="center">'.$row['payment'].'</td></td>
  	</tr>';
    }

    /* free result set */
    mysqli_free_result($result);
}

?>

  </tbody>
 </table>
 
	<?php
}elseif ($_GET['action']=="my") {
	?><br>
	<div align="center"><span class="style1">Показаны ваши депозиты</span>
 </div>
<table width="930" border="0" cellpadding="0" cellspacing="0" id="tables">
<tbody>
    <tr bgcolor="<?=$site_color?>" style="color:#FFFFFF;">
	<td align="center" width="100px"><b>Кошелек</b></td>
	<td align="center" width="100px"><b>Депозит</b></td>
	<td align="center" width="100px"><b>Осталось</b></td>
	<td align="center" width="100px"><b>На вывод </b></td>
  </tr>  
    <?php
  $query = "SELECT * FROM deposit where wallet='".$_SESSION['wallet']."' ORDER BY time DESC LIMIT 50";

if ($result = mysqli_query($conn, $query)) {

    /* fetch associative array */
while ($row = mysqli_fetch_assoc($result)) {
		$wallet=$row['wallet'];
		
		$time1=$row['time']-time();
		if ($time1 < 1) {
			$time="00:00";
		}else {
			$time=gmdate("i:s", $time1);
		}
		
			if ($row['payment']=="waiting" or $row['payment']=="pending") {
		    $payment='<div class="countdown">'.$time;
		}else {
		     $payment=$row['payment'];
		}
		
		
		
       echo '<tr class="htt">
	<td align="center"><img border="0" align="center" src="pay.png"> '.$wallet.'</td>
    <td align="center"><img border="0" align="center" src="money.png"> '.$row['money'].' руб.</td>
	<td align="center">'.$payment.' </td></td>
	<td align="center"><img border="0" align="center" src="money.png"> '.$row['new_money'].' руб. </td>
  	</tr>';
    }

    /* free result set */
    mysqli_free_result($result);
}

?>

  </tbody>
 </table>
 
	<?php
}
 ?>