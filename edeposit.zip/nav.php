<?php
$users=mysqli_query($conn, 'select wallet from users');
$deposit = mysqli_query($conn, 'select money from deposit where payment="waiting"');
$payment = mysqli_query($conn, 'select money from deposit where payment="success"');
$orginal_withdraw_count=mysqli_query($conn, 'select money from deposit where payment="success"')->num_rows;	

?>
 
<table width="930px" border="0" bgcolor="">
	<tbody><tr align="center">
	 
		<td width="460" id="s"><a id="s2" href="#" style="text-decoration: none;"><font color="" size=" ">Участников : <font color="orange"><?=$users->num_rows;?></font> чел.&nbsp;&nbsp;&nbsp;&nbsp;
</font></a></td>
		
		<td width="460" id="s"><a id="s2" href="<?=$siteurl?>/sell/" style="text-decoration: none;  "><font color="" size=" ">Купить этот скрипт &nbsp;&nbsp;&nbsp;&nbsp;
</font></a></td>
		 	
		
	 
	</tr>
</tbody></table>


<table width="930px" border="0" bgcolor="D4D0C8">
	<tbody><tr align="center">
	 
		<td width="460" id="s"><a id="s2" href="<?=$siteurl?>?page=main" style="text-decoration: none;"><font color="" size=" ">Открытые депозиты (<b><?=$deposit->num_rows;?></b>)</font></a></td>
		
		<td width="460" id="s"><a id="s2" href="<?=$site?>?page=main&payments=on" style="text-decoration: none;  "><font color="" size=" ">Выплаты (<b><?=$orginal_withdraw_count?></b>)</font></a></td>
		 	
	</tr>

</tbody></table>
