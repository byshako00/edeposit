<?php
		session_start(); 
		require_once('config.php');
		?>
		
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		
	<?php
	if ($option['site_mode']=="off") {
    exit('Сайт в режиме обслуживания');
}
	?>
		
	<?php
$query = "SELECT * FROM deposit where payment='waiting'";
if ($result = mysqli_query($conn, $query)) {
    while ($row = mysqli_fetch_assoc($result)) {
		$time1=$row['time']-time();
		if ($time1 > 1) {
		}elseif ($row['payment']=="success") {
		}elseif ($row['payment']=="fail") {
		}else {
				$insert="UPDATE deposit SET payment='pending' WHERE id='".$row['id']."'";
			if (mysqli_query($conn, $insert)) {} else {}	
		}
    }
    mysqli_free_result($result);
}
?>	
		
		<title><?=$title?></title>
		 <meta charset="UTF-8">
  <meta name="description" content="<?=$site_desc?>">
  <meta name="author" content="Shahin Mukhtarov (MvFalcon)">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="shortcut icon" href="icon.jpg" type="image/jpeg">
		<style type="text/css">
		#tables{background-color:#F5F5F5;}
		 
		#tables td{border:red 1px solid;}
		
		#s{ background-color:<?=$site_color?>; padding:2px; border-radius:5px; padding-left:7px; padding-right:7px; font-weight:bold; color:#FFFFFF; }
		#s:hover{ background-color:#FFFFFF; color:<?=$site_color?>; }
#s2{ display:block; color:#FFFFFF;}
#s2:hover{ color:<?=$site_color?>;}
        body{ 
        margin:0; 
        font:0.82em/1.4 Verdana,sans-serif; 
        min-width:780px; 

        background: #000000 url("body.jpg") repeat fixed 50% 50% / cover; 
        }
		p{
			margin:1em 0
		 }
		table{
			margin:0 auto;
			font:1.01em/1.4 Arial,sans-serif;
			background: #f4f4f4;
			color:#000
			}
		a{text-decoration:none;}
		.htt:hover {background-color:#ccffcc;}
		
		input:focus{
background-image:none;}
		input{ border-radius:8px;}
		</style>
		<script type = "text/javascript"  src = "http://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script>
		$(document).ready(function(){
			setInterval(function(){
				$('.countdown').each(function(){
					var time=$(this).text().split(':');
					var timestamp=time[0]*60+ time[1]*1;timestamp-=timestamp>0;
					
					var minutes=Math.floor(timestamp/60);
					var seconds=timestamp- minutes*60;
					
				if(minutes<10){minutes='0'+ minutes;}
				if(seconds<10){seconds='0'+ seconds;}
				if(timestamp>0){
				$(this).text(minutes+':'+ seconds);
				}else{
				$(this).text('В обработке');
				}
				});
		},1000);

		})
		</script>
		<script>
function updateText(text){
var percented_num = (text / 100) * <?=$percent?>;
var percented_num1 = Number(percented_num)+Number(text);
document.getElementById("result").innerHTML ="ваш доход: "+percented_num1+" руб";
}
</script>
</head>
<body bgcolor="D9EDF7" background="body.jpg">
    
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-104197327-1', 'auto');
  ga('send', 'pageview');

</script>
    
    
<table><tr><td>
  <?=base64_decode($option['header_ad_1'])?>
<center>
</td><td>
   <?=base64_decode($option['header_ad_2'])?>
<center>
</td></tr></table>

	<div style="border:#fff dotted 2px; border-radius:10px; width:930px; margin:auto; padding:2px; background-color:#F5F5F5">
	<? include('nav.php') ?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="F5F5F5">
<tbody><tr>
	<td colspan="2">
		<center>
			<table width="930" style=" background-color:#F5F5F5;">
			<tbody><tr>
				<td>
				<table width="530">
					<tbody><tr>
				                
						<td width="200"><center><a href="<?=$siteurl?>"><font color="#6f7782">Главная</font></a></center></td>
						<?php
						if ($_SESSION['code']==$admin_code) {
						echo '<td width="200"><center><a href="'.$siteurl.'/adminpanel.php"><font color="#6f7782">Панель администратора</font></a></center></td>';
						}
												?>
						<td width="150"><center><a href="<?=$siteurl?>?page=faq"><font color="#6f7782">F.A.Q</font></a></center></td>
						<td width="100"><center><a href="<?=$siteurl?>?page=contacts"><font color="#6f7782">Поддержка</font></a></center></td>
						<td width="100"><center><a href="<?=$siteurl?>?page=about"><font color="#6f7782">О нас</font></a></center></td>
					 </tr>
				</tbody></table>
				</td>
			</tr>
			</tbody></table>
		</center> 
	</td>
</tr>

<tr>
          	<td colspan="2" height="30" width="930" valign="top">
	<center><br>
		<img src="./logo.png" alt="Шапка сайта" >
		<br>
</center><br>
	</td>
</tr>
</tbody></table>

<?php
$page='page/'.$_GET['page'];
if (file_exists($page.'.php') == TRUE && $_GET['page']!=="index") {
include($page.'.php');
}else {
 
include('page/main.php');	
}
?>



<br>
<hr>


<table width="530">
	<tbody><tr>
		<td width="100"><center><a href="<?=$siteurl?>?page=rules"><font color="#6f7782">Правила</font></a><br>

</center></td>
		<td width="100"><center><a href="https://payeer.com/?partner=1263568" target="_blank"><img src="<?=$siteurl?>payeer.png" width="72px" height="32px" alt="payeer" title="payeer"></a></center></td>
		<td width="200"><center>Copyright © 2017. <br>Продажа скриптов: <a href="http://e-deposit.xyz/sell/#" target="blank">Нажмите, чтобы купить</a> </center></td>
	</tr>
</tbody></table>

</div>

<table><tr><td>
  <?=base64_decode($option['footer_ad_1'])?>
<center>
</td><td>
   <?=base64_decode($option['footer_ad_2'])?>
<center>
</td></tr></table>

</body></html>